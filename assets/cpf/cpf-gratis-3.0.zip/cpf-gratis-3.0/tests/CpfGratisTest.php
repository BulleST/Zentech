<?php

namespace JansenFelipe\CpfGratis;

use PHPUnit_Framework_TestCase;

class CpfGratisTest extends PHPUnit_Framework_TestCase {

    public function testGetParams() {

        $this->assertEquals(true, true);
    }

}
